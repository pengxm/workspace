Introduction
============
Power MP3 WMA Converter is a program that can convert any audio files from one format to another. It also supports change bit rate for MP3 or WMA format audio file. With a converter list, you can convert a large number of audio files at one time easily. It also have some very useful function, such as change tag information, auto renaming. 


What's New 
==========

[ Legend ]
* Bug fix
+ New function add
& Known problem

[ Version 1.14] - 2003/05/24
+ ogg audio format read supported
+ ogg audio format write supported

[ Version 1.13a] - 2003/04/24
* bug fixed

[ Version 1.13 ] - 2003/04/03
+ CD ripping function supported !!!
* bug fixed

[ Version 1.12 ] - 2003/04/02
* Auto name function bug fixed
+ Combine several audios into one audio function added

[ Version 1.11 ] - 2003/02/22
+ Cool Skin added

[ Version 1.10 ] - 2002/12/18
* Core converting code re-written
* Main functions re-designed
* Some useful functions added

[ Version 1.05 ] - 2002/10/26
* Fixed bug of converting some long wma file
* Fixed bug of sometime crashing when cancel converting

[ Version 1.04 ] - 2002/09/14
* Support Genre Setting
* Support Group Setting Genre and Track
* Support For ID3V1 & ID3V2

[ Version 1.03 ] - 2002/09/05
* Fixed Add directory function bug
+ Numeric display of converting progress

[ Version 1.02 ] - 2002/07/13
* Tag rule splitter setable
* Help file quality enhanced

[ Version 1.01 ]
* Minor bug fixed.

[ Version 1.00 ]
* The first release version.
